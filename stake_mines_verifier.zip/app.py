from flask import Flask, render_template, request, send_file, jsonify
import io, hmac, hashlib
import matplotlib.pyplot as plt

app = Flask(__name__)
history = []

def gen_positions(cs, ss, nonce, mcount):
    msg = f"{cs}:{nonce}".encode()
    key = ss.encode()
    h = hmac.new(key, msg, hashlib.sha256).hexdigest()
    arr = bytearray.fromhex(h)
    mines = []
    i = 0
    while len(mines) < mcount:
        pos = arr[i % len(arr)] % 25
        if pos not in mines:
            mines.append(pos)
        i += 1
    return sorted(mines), sorted(set(range(25)) - set(mines))

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        cs = request.form["client_seed"]
        ss = request.form["server_seed"]
        nonce = int(request.form["nonce"])
        mcount = int(request.form["mine_count"])
        mines, safe = gen_positions(cs, ss, nonce, mcount)
        history.insert(0, {"cs": cs, "ss": ss, "nonce": nonce, "mcount": mcount, "safe": safe})
        result = {"mines": mines, "safe": safe}
    return render_template("index.html", result=result, history=history[:5])

@app.route("/download_board", methods=["POST"])
def download_board():
    data = request.get_json()
    mines = data["mines"]
    safe = data["safe"]
    fig, ax = plt.subplots(figsize=(4, 4))
    for r in range(5):
        for c in range(5):
            idx = r * 5 + c
            col = "green" if idx in safe else "red"
            ax.add_patch(plt.Rectangle((c, 4 - r), 1, 1, color=col, edgecolor="black"))
            ax.text(c + 0.5, 4 - r + 0.5, str(idx), ha="center", va="center", fontsize=8)
    ax.axis('off')
    buf = io.BytesIO()
    plt.savefig(buf, dpi=150, bbox_inches='tight')
    buf.seek(0)
    return send_file(buf, mimetype="image/png", download_name="stake_board.png")

@app.route("/history_json")
def history_json():
    return jsonify(history[:5])
